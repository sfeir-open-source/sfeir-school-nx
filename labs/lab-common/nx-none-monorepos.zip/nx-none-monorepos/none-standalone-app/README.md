# none-standalone-app

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build none-standalone-app` to build the library.

## Running unit tests

Run `nx test none-standalone-app` to execute the unit tests via [Jest](https://jestjs.io).
