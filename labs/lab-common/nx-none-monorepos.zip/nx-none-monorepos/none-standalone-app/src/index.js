export * from './lib/none-standalone-app';
