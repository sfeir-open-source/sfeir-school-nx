export function commonlib(): string {
  return 'commonlib';
}

export function getTodayDate(){
  return new Date();
}