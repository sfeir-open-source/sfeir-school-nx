import { commonlib } from './commonlib';

describe('commonlib', () => {
  it('should work', () => {
    expect(commonlib()).toEqual('commonlib');
  });
});
